1. Micah Wagner, micah.wagner@wsu.edu

2. 
	RE_TO_NFA.py is the python file that converts regular expression from argv[1] into NFAs

	README.md is this file

3. This python program uses python3. To run the code, I just used what the school server uses.

4. I use python so you dont need to compile the program

5. To build / run the code on the server, type " python3 RE_TO_NFA.py someinputfile.txt ". 
This will output to stdout, so if you want to capture the output in some file, you can run 
" python3 RE_TO_NFA.py someinputfile.txt > someoutputfile.txt ". The input file should contain a 
a list of regexs in postfix notation, with each regex on a seperate line.   